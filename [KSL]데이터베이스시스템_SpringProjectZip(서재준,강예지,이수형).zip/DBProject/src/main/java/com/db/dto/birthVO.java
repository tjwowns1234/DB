package com.db.dto;

public class birthVO {

	String d_name;

	public String getD_name() {
		return d_name;
	}

	public void setD_name(String d_name) {
		this.d_name = d_name;
	}


	
	

	
	
}
