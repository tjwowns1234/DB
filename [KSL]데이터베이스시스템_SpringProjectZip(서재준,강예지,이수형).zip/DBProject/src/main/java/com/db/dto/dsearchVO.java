package com.db.dto;

public class dsearchVO {

	private String key;
	private String r_id;
	
	public int getR_id() {
		return Integer.parseInt(r_id);
	}
	
	public void setR_id(String r_id) {
		this.r_id = r_id;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	

	

	


	
	

	
	
}
