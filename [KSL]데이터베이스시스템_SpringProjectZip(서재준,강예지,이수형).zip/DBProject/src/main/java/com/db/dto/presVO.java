package com.db.dto;

public class presVO {
	
    private String p_name;
    private String m_name;
    private String d_id;
    
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public int getD_id() {
		return Integer.parseInt(d_id);
	}
	public void setD_id(String d_id) {
		this.d_id = d_id;
	}
    
    
    
	
	
	
}
