package etc;

import java.math.BigInteger;

public class real_estate_categoryVO {

/* REPriceVO VIEW */	
	String TYPE_ID;
	String TYPE_NAME;
	public int getTYPE_ID() {
		return Integer.parseInt(TYPE_ID);
	}
	public void setTYPE_ID(String tYPE_ID) {
		TYPE_ID = tYPE_ID;
	}
	public String getTYPE_NAME() {
		return TYPE_NAME;
	}
	public void setTYPE_NAME(String tYPE_NAME) {
		TYPE_NAME = tYPE_NAME;
	}

	
	
	
	
	
}
