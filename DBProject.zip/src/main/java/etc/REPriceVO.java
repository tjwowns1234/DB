package etc;

import java.math.BigInteger;

public class REPriceVO {

/* REPriceVO VIEW */	
	String ADDRESS;
	BigInteger PRICE;
	float PY;
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public BigInteger getPRICE() {
		return PRICE;
	}
	public void setPRICE(BigInteger pRICE) {
		PRICE = pRICE;
	}
	public float getPY() {
		return PY;
	}
	public void setPY(float pY) {
		PY = pY;
	}
	
	
	
	
}
