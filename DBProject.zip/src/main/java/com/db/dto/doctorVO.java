package com.db.dto;

public class doctorVO {
	
    private String d_id;
    private String d_password;
    private String d_name;
    private String d_birth_of_date;
    private String d_gender;
    private String d_major;
    private String d_office_number;
	
	public String getD_ii() {
		return d_id;
	}
	public void setD_di(String d_id) {
		this.d_id = d_id;
	}
	public String getD_password() {
		return d_password;
	}
	public void setD_password(String d_password) {
		this.d_password = d_password;
	}
	public String getD_name() {
		return d_name;
	}
	public void setD_name(String d_name) {
		this.d_name = d_name;
	}
	public String getD_birth_of_date() {
		return d_birth_of_date;
	}
	public void setD_birth_of_date(String d_birth_of_date) {
		this.d_birth_of_date = d_birth_of_date;
	}
	public String getD_gender() {
		return d_gender;
	}
	public void setD_gender(String d_gender) {
		this.d_gender = d_gender;
	}
	public String getD_major() {
		return d_major;
	}
	public void setD_major(String d_major) {
		this.d_major = d_major;
	}
	public String getD_office_number() {
		return d_office_number;
	}
	public void setD_office_number(String d_office_number) {
		this.d_office_number = d_office_number;
	}
	
	
}
